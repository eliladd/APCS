import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Color;

import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;


public class Screen extends JPanel implements MouseListener{
    private Game game;

	// Initialization Constructor
	public Screen() {
        game = new Game();
        addMouseListener(this);
	}
	
	//set the size of the JPanel container
	@Override
	public Dimension getPreferredSize(){
		return new Dimension(800,600);
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
        game.drawGrid(g);
		
		
	}
	
	//INCLUDE ALL METHODS OF MOUSELISTENER REGARDLESS IF  
    //YOU USE THEM OR NOT IN ORDER FOR MOUSELISTENER TO WORK!!!!
    public void mousePressed(MouseEvent e) {
        System.out.println("Mouse Pressed");
        int x = e.getX();
        int y = e.getY();
        
        game.insertXO(x, y);

        repaint();
    }

    public void mouseReleased(MouseEvent e) {}

    public void mouseEntered(MouseEvent e) {}

    public void mouseExited(MouseEvent e) {}

    public void mouseClicked(MouseEvent e) {}
}